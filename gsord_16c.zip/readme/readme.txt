27 December 2016

korkins@gmail.com
sergey.v.korkin@nasa.gov

This file provides step-by-step guidance on how to compile RT code SORD under
Linux for a simple 1-layer case. The gfortran compiler is rquired.


*****************
I.HOW TO GET SORD
*****************

Zippped source files for the code are available from

		ftp://maiac.gsfc.nasa.gov/pub/skorkin

or by email request from the developer (see above). The zip file name shows
date of release. The most recent version should be used.


********************************
II. HOW TO INSTALL AND TEST SORD
********************************

1. Download and unzip gsord
2. Execute build_iqu.lin (use chmod u+x). This creates gsord_iqu.exe
3. Run ./gsord_iqu.exe
4. In about 2 minutes (for an average desktop PC), output/output_iqu.dat is created
5. Compare this file against output/check_output_iqu.dat


*************************
III. UNDERSTANDING OUTPUT
*************************

1. Columns, left to right, in the output_iqu.dat file:

   	- Solar zenith angle, SZA, in degrees
	- Azimuth angle, AZA, in degrees
	- View zenith angle (VZA) in degrees
		VZA < 90 correspond to reflected radiation (to the space)
		VZA > 90 correspond to transmitted radiation (to the ground)
		VZA = 90 (horizon) is not computed
	- I-component
	- Q-component
	- U-component
		Components of the Stokes vector, S, are normalized to pi/(mu0*Fo),
		where Fo is the incident flux on top of atmosphere
	- Total atmosphere optical thickness
	- Single scattering albedo
	- Average scattering cosine

2. RT code SORD follows Hovenier JW, van der Mee C, and Domke H, "Transfer of
   polarized light in planetary atmopsheres. Basic concepts and principal methods",
   Kluwer Academic Publishers, 2004 in definition of the coordinate system.


************************
III. UNDERSTANDING INPUT
************************

1. The input file is located in input/input_iqu.dat
2. Each input parameter comes with a brief description
3. Some recomendations on selecting the input parameters
	(1.1) - Number of streams per hemisphere, N - for most aerosol cases, 16-32 is sufficient
	(1.2) - Number of azimuth expansion (Fourier) moments can be kept equal to 2N. Automatic
                convergence criterion (see below) skips unnecessary Fourier moments.
		Azimuth-average corresponds to the number of Fourier moments equals 1 (m=0 only)
	(1.3) - Step, dTau, for numerical integration over optical thickness: dTau = 0.01-0.02
	(1.4) - Absolute error for automatic convergence: epsi ~ 1E-6
4. Definition of geometry (see reference above for details)
	(2.1) - SZA < 90
	(2.2) - Upward directions (VZA < 90), if any, must come first, followed by
		downward direction (VZA > 90), if any
	(2.3) - AZA = 0 corresponds to forward scattering
5. Atmopsheric parameters
	(3.3) - Aerosol optical thickness, AOT: this exaple creats LUT over AOTs

			11
			0.3262 0.4262

		with 11 values of AOT and step (0.4262 - 0.3262)/(11-1) = 0.01. For
		a single value of AOT, the final value (0.4262 in this example) is ignored.

		NOTE: SORD was tested for AOTs up to 10 and showed good accuracy.

	(3.5) - Columns in file with expansion moments, left to right:
		- Number of moment, starting from 0
		- a1k (element 11)
		- a2k (element 22)
		- a3k (element 33)
		- a4k (element 44)     - not used in SORD
		- b1k (element 12=21)
		- b2k (element 34=-43) - not used in SORD

	All coefficients include (2k+1).

	For simulation of light scattering by spherical particles, the Michael Mishchenko's Mie code
	can be conviniently used with SORD (no adjustments of signs needed). The Mie code is available
        from

		http://www.giss.nasa.gov/staff/mmishchenko/brf/spher.f

	For the user's conveneince, it was downloaded from the website (27 Dec 2016) and included in
	mmishchenko_mie/spher.f.

	By default, the aerosol case from Alexander Kokhanovsky et al, 2010: "Benchmark results in
        vector atmospheric radiative transfer", JQSRT 111, pp.1931-1946 is set up in input/input_iqu.dat.
	The user is referted to readme/definition_of_cases.pdf for details. The benchmark result
	computed with RT code SCIATRAN (Vladimir Rozanov) can be seen in

		readme/SCIATRAN_aerosol_refl_N_240.dat  - for reflection
		readme/SCIATRAN_aerosol_trans_N_240.dat - from transmittance

6. Surface parameters:
     	(4.1) Surface type
        	0 - no surface (black)
        	1 - Lambertian surface
        	2, 3 - N/A (reserved for RPV, mRPV)
        	4, 5 - RTLS and modified mRTLS
        	6 - Ocean: Nakajima-Tanaka model with polarization
        	7 - Ocean with specified wind azimuth
        	8,9 - N/A (reserved for the Nadal-Breon BPDF)
        	10 - linear mixture of 4 and 6
        	11 - linear mixture of 5 and 6

        	Note, for models 2 - RPV and 3 - mRPV, the code comes with necessary subroutine, RPV.f90.
		These can be quickly added upon user's request.
        	Unfortunately, published benchmarks for RT with this model are not available.

     	(4.2) Surface parameters
       		0 - 0.0 ( any number )
       		1 - r0, reflection coefficient
       		2, 3 - N/A
       		4, 5 - Kl Kv Kg ( Lambertian, volumetric, and geometric weights - space delimited )
       		6 - Re_h2o Im_h2o V_wind (refractive index of water: real and imaginary parts, and wind speed m/s)
       		7 - similar to 6 followed by wind azimuth, w_a, all space delimited
          		(this model has never been tested !!)
       		8 - N/A
       		9 - N/A
      		10 - Kl Kv Kg Re_h2o Im_h2o V_wind wgt, where 'wgt' defines mixing ratio:
          		 wgt*RTLS + (1 - wgt)*Ocean
      		11 - Kl Kv Kg Re_h2o Im_h2o V_wind w_a wgt (similar to model 10, but with w_a)

7. For checking purpose, check_input_iqu.dat allows to reset the input parameters to the default ones
   (rename it to input_iqu.dat before use). Aadditionaly, input parameters are copied on output -
   see input_iqu_echo.dat after ./gsord_iqu.exe is executed.


****************************************************************************
IV. COMPUTATION OF FLUXES, AND REFLECTANCE-TRANSMITTANCE-ABSORPTANCE (R-T-A)
****************************************************************************

1. These are computed in exactly the same way as the Stokes vector using this table:

	Quantity | Compile       | Run           | Input                 | Output
	----------------------------------------------------------------------------------------		
	Flux     | build_flx.lin | gsord_flx.exe | output/output_flx.dat | output/output_flx.dat
	----------------------------------------------------------------------------------------
	R-T-A    | build_rta.lin | gsord_rta.exe | output/output_rta.dat | output/output_rta.dat

2. Format of input for flux and r-t-a is similar to the one used for the Stokes vector. For both,
   the number of azimuth moments and view zenith angles are omitted (not used) on input.
   In addition to that, SZA is omitted for r-t-a.
3. For a conservative media, sum of the reflected and the total transmitted (direct + 
   diffuse) fluxes equals pi=3.1415... (incident flux on TOA for any SZA) and
   reflectance + transmittance equals 1.0 (conservation of energy)
4. Computation of fluxes and r-t-a requires only a few ordinates: 4-16 satisifies most cases.
5. Contents of the output_flx.dat:
	- SZA
        - Diffuse reflected flux on TOA
        - Diffuse reflected flux on BOA
        - Diffuse transmitted flux on BOA
        - Total (diffuse+direct) flux on BOA
        - AOT
        - SSA
        - Average scattering cosine
6. Contents of the output_rta.dat:
	- reflectance on TOA
        - transmittance on BOA
        - absorptance, 1.0-(r+t)
        - AOT
        - SSA
        - Average scattering cosine
=======================================================================================================================