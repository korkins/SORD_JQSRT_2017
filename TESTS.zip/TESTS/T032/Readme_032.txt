Scenario:
    Garcia RDM, and Siewert CE, 1989: The F_N method for radiative transfer models that include polarization effects, JQSRT, 41(2), pp.117-145.
    See p.138, Section 7.Numerical Results, for detailed explanation of the scenario. Case L=13.

Moments:
    Vestrucci P and Siewert CE, 1984: A numerical evaluation of an analytical representation of the components in a Fourier decomposition of the phase matrix for the scattering of polarized light, JQSRT, v.31(2), pp.177-183.
    See p.180, Table 4, Problem II - not as defined in SORD.
    See de Rooij WA and van der Stap CCAH, 1984: Expansion of Mie scattering matrices, Astron.Astrophys., v.131, p.243, Eq.(88), for relation of the benchmark and the SORD expansion moments.

Comment:
    1. mu = +/-0.0 are ignored in this test;
    2. Two last moments, xk, are ignored (small);
    3. The benchmark and SORD use different definition of the expansion moments.



