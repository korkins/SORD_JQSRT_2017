Scenario:
    See ..\INPUT_IPOL

Moments:
    de Rooij WA and van der Stap CCAH, Astron.Astrophys., 1984, V.131, pp.237-248.
    See Table 4, p.243, model C.

Comment:
    Moments, Xk, does NOT correspond to the given phase matrix, F(sca), but the benchmark results was computed for Xk, not F(sca).







