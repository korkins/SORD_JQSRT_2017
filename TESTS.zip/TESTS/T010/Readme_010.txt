Scenario:
    Korkin SV, Lyapustin AI, Rozanov VV, 2013: APC: A new code for atmospheric polarization computations, JQSRT, v.127, pp.1-11.
    See Section 6, p.8.

Comments:
    This benchmark perfectly coincide with SCIATRAN.