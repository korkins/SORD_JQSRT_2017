Scenario:
    Emde C et al, 2015: IPRT polarized radiative transfer model intercomparison project � Phase A, JQSRT, v.164, pp.8-36.
    See p.25, Section 3.3.2.

Comments:
    See also Case_B2.pdf and http://www.meteo.physik.uni-muenchen.de/~iprt/doku.php?id=intercomparisons:b2_absorption
    The benchmark result was generated with IPOL.

    *** WARNING *** Only PRIMARY SCATTERED RADIATION is tested in this benchmark



