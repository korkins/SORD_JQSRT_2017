Scenario:
    Emde C et al, 2015: IPRT polarized radiative transfer model intercomparison project � Phase A, JQSRT, v.164, pp.8-36.
    See p.26, Section 3.3.4.

Comments:
    See also Case_B4.pdf and http://www.meteo.physik.uni-muenchen.de/~iprt/doku.php?id=intercomparisons:b4_cloud_ocean
    The benchmark result was generated with IPOL.

    See .\Rayleigh_profile_ON-OFF(IPOL)\test.xls for estimation of influence of the Rayleigh profile in the IPRT-B4 particular scenario based on the IPOL (exact!) simulations.

    *** WARNING ***:
    1) Different Rayleigh profile: NLR=1, not 3
    2) dI% and dP at VZA = 80,85, 95,100 are assumed 0.0 MANUALLY.
       Otherwise, max(dI%) goes up to 18% at the horizon.

