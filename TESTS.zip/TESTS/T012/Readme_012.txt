Scenario:
    Wauben WMF, de Haan JF, Hovenier JW, 1994: A method for computing visible and infrared polarized monocromatic radiation in planetary atmospheres, Astron.Astroph., v.282, pp.277-290.
    See p.284, Section 5, for detailed explanation of the scenario.
    See p.285, Tables 1-2, for results.

Moments:
    de Rooij WA and van der Stap CCAH, 1984: Expansion of Mie scattering matrices in generalized spherical functions, Astron.Astrophys., v.131, pp.237-248.
    See Table 4, p.243, model C.

Comments:
    Horizontal observation, mu = +/-0.0, is ignored in this test.