Scenario:
    Siewert CE, 2000: A discrete-ordinates solution for radiative-transfer models that include polarization effects, JQSRT, v.64, pp.227-254.

Moments:
    Same paper, p.246, Table 1 - not as defined in SORD.
    See de Rooij WA and van der Stap CCAH, 1984: Expansion of Mie scattering matrices, Astron.Astrophys., v.131, p.243, Eq.(88), for relation of the benchmark and the SORD expansion moments.
    In the definition used in SORD, the moments are reported in >>
     >>Kuik F, de Haan JF, Hovenier JW, 1992: Benchmark results for single scattering by spheroids, JQSRT v.47(6), p.477-489.
       See p.482, Table 6.

Comment:
    Horizontal direction, mu = +/-0.0, are ignored in this test.