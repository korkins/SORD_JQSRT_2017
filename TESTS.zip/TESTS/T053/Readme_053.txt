Scenario:
    Emde C et al, 2015: IPRT polarized radiative transfer model intercomparison project � Phase A, JQSRT, v.164, pp.8-36.
    See p.26, Section 3.3.3.

    *** Except for RTLS surface is used instead of black ***

Comments:
    See also Case_B3.pdf and http://www.meteo.physik.uni-muenchen.de/~iprt/doku.php?id=intercomparisons:b3_aerosol
    The benchmark result was generated with IPOL.



