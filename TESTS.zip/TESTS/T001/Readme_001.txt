Scenario:
    Wauben WMF, de Haan JF, Hovenier JW, 1993: Low orders of scattering in plane-parallel homogeneous atmopshere, Astron.Astrophys., v.276, pp.589-602.
    See p.595, Section 6.1 for definition of the case.
    See p.596, Table 1, column "First" for the result.

Moments:
    de Rooij WA and van der Stap CCAH, 1984: Expansion of Mie scattering matrices in generalized spherical functions, Astron.Astrophys., v.131, pp.237-248.
    See Table 4, p.243, model C.

Comment:
    Moments, Xk, do NOT correspond to the given phase matrix, F(sca), but the benchmark results was computed for Xk, not F(sca).