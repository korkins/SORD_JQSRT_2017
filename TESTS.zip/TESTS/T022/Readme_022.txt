Scenario:
    Emde C et al, 2015: IPRT polarized radiative transfer model intercomparison project � Phase A, JQSRT, v.164, pp.8-36.
    See p.20, Section 3.2.2.

Comments:
    See also CaseA2.pdf and http://www.meteo.physik.uni-muenchen.de/~iprt/doku.php?id=intercomparisons:a2_lambert
    The benchmark result was generated with IPOL.

