Scenario:
    Garcia RDM and Siewert CE, 2011: A simplified implementation of the discrete-ordinates method for a class of problems in radiative transfer with polarization, JQSRT, v.112, pp.2801-2813.
    See p.2805, Table 1: Case 4. Results: p.2808, Tables 8-9.

Moments:
    Vestrucci P and Siewert CE, 1984: A numerical evaluation of an analytical representation of the components in a Fourier decomposition of the phase matrix for the scattering of polarized light, JQSRT, v.31(2), pp.177-183.
    See p.181, Table 7, Problem III - not as defined in SORD.
    See de Rooij WA and van der Stap CCAH, 1984: Expansion of Mie scattering matrices, Astron.Astrophys., v.131, p.243, Eq.(88), for relation of the benchmark and the SORD expansion moments.

Comment:
    1. mu = +/-0.0 are ignored in this test;
    2. Seven last moments, xk, are ignored (small);
    3. The benchmark and SORD use different definition of the expansion moments.