Scenario:
    Wauben WMF and Hovenier JW, 1992: Polarized radiation of an atmosphere containing randomly-oriented spheroids, JQSRT, v.47(6), pp.491-504.
    See Tables 1-8, Model 1.

Moments:
    Kuik F, de Haan JF, Hovenier JW, 1992: Benchmark results for single scattering by spheroids, JQSRT v.47(6), p.477-489.
    See p.481, Table 5.
    
Comment:
    Horizontal direction, mu = +/-0.0, are ignored in this test.