Scenario:
    Mishchenko MI, 1990: The fast invariant imbedding method for polarized light: computational aspects and numerical results for Rayleigh scattering, JQSRT, 43(2), pp.163-171.
    See Table 5, p.170, for results: SSA=exp(-g*Tau), Case g=0.01. 

Comments:
    NLR may or may not coincide with NL in the test.


