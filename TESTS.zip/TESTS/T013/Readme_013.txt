Scenario:
    de Haan JF, Bosma PB, Hovenier JW, 1987: The adding method for multiple scattering calculations of polarized light, Astron. Astrophys, v.183, pp.371-391.
    See p.389, Tables 5 & 7.

Moments:
    de Rooij WA and van der Stap CCAH, 1984: Expansion of Mie scattering matrices in generalized spherical functions, Astron.Astrophys., v.131, pp.237-248.
    See Table 4, p.243, model C.

Comment:
    Moments, Xk, do NOT correspond to the given phase matrix, F(sca), but the benchmark results was computed for Xk, not F(sca).







